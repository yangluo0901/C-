namespace quote_dojo.Models
{
    public class Quote
    {
        public string content {get;set;}
    }
}