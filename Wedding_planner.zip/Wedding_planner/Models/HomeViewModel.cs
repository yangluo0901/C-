namespace Wedding_planner.Models
{
    public class LogRegModel
    {
        public LogUser loguser{get;set;}
        public RegUser newuser{get;set;}
    }
}