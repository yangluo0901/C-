namespace restauranter
{
    public class MySqlOptions
    {
        public string name {set;get;}
        public string connectionstring {set;get;}
    }
}