﻿// Write your JavaScript code.
